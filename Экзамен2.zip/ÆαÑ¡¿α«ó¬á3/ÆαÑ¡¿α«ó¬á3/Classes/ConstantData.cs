﻿using System;
using System.Collections.Generic;
using System.Text;

namespace Тренировка3.Classes
{
    class ConstantData
    {
        public static string Atricle;
        public static MySql.Data.MySqlClient.MySqlConnection con = new MySql.Data.MySqlClient.MySqlConnection("server=localhost;user=root;pwd=Ivan2004;database=trade000");
        public static int All;
    }
}
